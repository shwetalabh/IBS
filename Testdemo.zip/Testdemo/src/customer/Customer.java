package customer;

public class Customer {

		// TODO Auto-generated method stub
		private String c_name;
		private int acc_no;
		public String getc_name()
		{
			return c_name;
	
		}
		public void setc_name(String c_name)
		{
			this.c_name=c_name;
		}
		
		public int getacc_no()
		{
			return acc_no;
	
		}
		public void setacc_no(int acc_no)
		{
			this.acc_no=acc_no;
		}
  
	  
	}


